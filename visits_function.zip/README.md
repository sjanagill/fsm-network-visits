
#  Code repository for Cloud Function 'visits_to_bq'

This function is called from the Scheduler which runs hourly, load file from a bucket which will receive visits info in CSV format.

- Called from a hourly scheduler
- Load file from storage bucket
- Check if visits bq table exists, otherwise create using provided schema.
- Inserts the data fromfile to bq table.


![FMS_Network_Visits](../../FMS_Network_Visits.jpg "FMS_Network_Visits")


## Repository
This repository contains the code for the Code repository for Cloud Function 'visits_to_bq'